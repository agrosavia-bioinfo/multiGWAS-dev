library(testthat)
library(GAPIT3)

test_check("GAPIT3")
